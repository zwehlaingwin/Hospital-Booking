 <footer class="site-footer">

    <div class="site-footer__inner container container--narrow">

      <div class="group">

        <div class="site-footer__col-one">
          <h1 id="zhw"><p>&copy <?php echo date('Y') ?> Zwe Hlaing WIn</p></h1>
       
        </div>

      <h2 class="connect">Connect with Us</h2>
      <a href="#" class="fa fa-facebook"></a>
       
        
      </div>

    </div>
  </footer>
  
  
</body>
</html>




</body>
</html>