<?php

	register_side(array
		(
			'name'=> 'first',
			'id'=>'first',
			'before_widget' => '<div>',
			'after_widget' => '</div>'



		));

	register_side(array
		(
			'name'=> 'second',
			'id'=>'second',
			'before_widget' => '<div>',
			'after_widget' => '</div>'



		));



?>