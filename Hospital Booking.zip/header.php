<!DOCTYPE html>
<html>
<head>
	<title>Hospital Booking</title>
	<link rel='stylesheet' href="<?php bloginfo('stylesheet_url');?>"/>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<?php wp_head(); ?>
</head>

<body>
	 <header class="site-header">
    <div class="container">    
     
      <i class="site-header__menu-trigger fa fa-bars" aria-hidden="true"></i>
      <div class="site-header__menu group">
        <nav class="main-navigation">
         <?php wp_nav_menu()?>
        </nav>
      </div>
    </div>
  </header>

