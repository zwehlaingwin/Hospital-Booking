<aside>

	<div id='one'><?php dynamic_sidebar('first');?></div>
	<div id='second'><?php dynamic_sidebar('second');?></div>

</aside>