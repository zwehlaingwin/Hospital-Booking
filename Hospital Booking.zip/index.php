<?php get_header();?>

<?php get_sidebar('first');?>

 <div class="page-banner">
  <div class="page-banner__bg-image" style="background-image: url(<?php echo get_theme_file_uri('/images/hospital.jpg')  ?>);"></div>
    <div class="page-banner__content container t-center c-white">
      <h1 class="headline headline--large">Safe Ur Life!</h1>
      
      <a href="#" class="btn btn--large btn--blue">Booking Apporiment</a>
    </div>
  </div>

 

  <?php while(have_posts()):the_post()?>
  	<?php the_title();?>

  	<?php the_content();?>


  <?php endwhile; ?>

  <?php get_sidebar('second');?>
<?php get_footer(); ?>